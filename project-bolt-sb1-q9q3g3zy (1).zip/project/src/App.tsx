import React, { useState } from 'react';
import { 
  Calendar, 
  BookOpen, 
  Bell, 
  MapPin, 
  MessageSquare, 
  FileText, 
  ClipboardList,
  Menu,
  X,
  Clock,
  Users,
  Star,
  ChevronRight,
  GraduationCap
} from 'lucide-react';

interface NavItem {
  id: string;
  label: string;
  icon: React.ComponentType<any>;
}

interface TimeSlot {
  subject: string;
  time: string;
  room: string;
  type: string;
}

interface SemesterSchedule {
  [key: string]: TimeSlot[];
}
interface Notice {
  id: string;
  title: string;
  date: string;
  description: string;
  isNew: boolean;
}

interface Event {
  id: string;
  name: string;
  date: string;
  image: string;
  registered: number;
}

interface Test {
  id: string;
  subject: string;
  date: string;
  time: string;
  assignedTo: string;
}

interface Book {
  id: string;
  title: string;
  author: string;
  cover: string;
}

const navItems: NavItem[] = [
  { id: 'timetable', label: 'Timetable', icon: Calendar },
  { id: 'notices', label: 'Academic Notices', icon: Bell },
  { id: 'ebooks', label: 'E-Books', icon: BookOpen },
  { id: 'events', label: 'Event Notices', icon: Users },
  { id: 'feedback', label: 'User Feedback', icon: MessageSquare },
  { id: 'tests', label: 'Test Schedules', icon: ClipboardList },
  { id: 'map', label: 'Campus Map', icon: MapPin },
];

const semesterSchedules: SemesterSchedule = {
  '3rd': [
    { subject: 'Data Structures & Algorithms (DSA)', time: '09:00 - 10:00', room: 'Room 301', type: 'Lecture' },
    { subject: 'Object Oriented Programming (OOPS)', time: '10:15 - 11:15', room: 'Lab 2', type: 'Practical' },
    { subject: 'Discrete Mathematics', time: '11:30 - 12:30', room: 'Room 205', type: 'Lecture' },
    { subject: 'Digital Design & Computer Organization (DDCO)', time: '14:00 - 15:00', room: 'Room 401', type: 'Lecture' },
    { subject: 'OOPS Lab', time: '15:15 - 16:15', room: 'Lab 1', type: 'Practical' },
  ],
  '5th': [
    { subject: 'Computer Networks (CN)', time: '09:00 - 10:00', room: 'Room 302', type: 'Lecture' },
    { subject: 'Operating Systems (OS)', time: '10:15 - 11:15', room: 'Room 203', type: 'Lecture' },
    { subject: 'Formal Language & Automata Theory (FLAT)', time: '11:30 - 12:30', room: 'Room 305', type: 'Lecture' },
    { subject: 'Artificial Intelligence (AI)', time: '14:00 - 15:00', room: 'Room 402', type: 'Lecture' },
    { subject: 'CN Lab', time: '15:15 - 16:15', room: 'Lab 3', type: 'Practical' },
  ],
  '7th': [
    { subject: 'Machine Learning (Elective)', time: '09:00 - 10:00', room: 'Room 501', type: 'Lecture' },
    { subject: 'Cloud Computing (Elective)', time: '10:15 - 11:15', room: 'Room 502', type: 'Lecture' },
    { subject: 'Blockchain Technology (Elective)', time: '11:30 - 12:30', room: 'Room 503', type: 'Lecture' },
    { subject: 'Project Work', time: '14:00 - 16:00', room: 'Project Lab', type: 'Project' },
  ],
};

const notices: Notice[] = [
  {
    id: '1',
    title: 'Mid-Semester Examination Schedule Released',
    date: '2025-01-15',
    description: 'The mid-semester examination schedule for all departments has been released. Check your respective timetables.',
    isNew: true
  },
  {
    id: '2',
    title: 'Library Timings Extended During Exams',
    date: '2025-01-14',
    description: 'Library will remain open until 11 PM during examination period starting January 20th.',
    isNew: true
  },
  {
    id: '3',
    title: 'Workshop on Machine Learning - Registration Open',
    date: '2025-01-13',
    description: 'Three-day workshop on Machine Learning fundamentals. Limited seats available.',
    isNew: false
  },
];

const events: Event[] = [
  {
    id: '1',
    name: 'Tech Fest 2025',
    date: 'Feb 15-17, 2025',
    image: 'https://images.pexels.com/photos/2004161/pexels-photo-2004161.jpeg?auto=compress&cs=tinysrgb&w=400',
    registered: 234
  },
  {
    id: '2',
    name: 'Career Fair',
    date: 'Jan 25, 2025',
    image: 'https://images.pexels.com/photos/7688460/pexels-photo-7688460.jpeg?auto=compress&cs=tinysrgb&w=400',
    registered: 189
  },
  {
    id: '3',
    name: 'Cultural Night',
    date: 'Feb 2, 2025',
    image: 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=400',
    registered: 156
  },
];

const upcomingTests: Test[] = [
  { id: '1', subject: 'Data Structures', date: 'Jan 22, 2025', time: '10:00 AM', assignedTo: 'Dr. Smith' },
  { id: '2', subject: 'Database Management', date: 'Jan 24, 2025', time: '02:00 PM', assignedTo: 'Prof. Johnson' },
  { id: '3', subject: 'Computer Networks', date: 'Jan 26, 2025', time: '09:00 AM', assignedTo: 'Dr. Williams' },
];

const ebooks: Book[] = [
  { id: '1', title: 'Introduction to Algorithms', author: 'Cormen, Leiserson', cover: 'https://images.pexels.com/photos/159711/books-bookstore-book-reading-159711.jpeg?auto=compress&cs=tinysrgb&w=300' },
  { id: '2', title: 'Clean Code', author: 'Robert C. Martin', cover: 'https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg?auto=compress&cs=tinysrgb&w=300' },
  { id: '3', title: 'Database Systems', author: 'Elmasri & Navathe', cover: 'https://images.pexels.com/photos/256455/pexels-photo-256455.jpeg?auto=compress&cs=tinysrgb&w=300' },
  { id: '4', title: 'Computer Networks', author: 'Andrew Tanenbaum', cover: 'https://images.pexels.com/photos/267586/pexels-photo-267586.jpeg?auto=compress&cs=tinysrgb&w=300' },
];

function App() {
  const [activeSection, setActiveSection] = useState('timetable');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [selectedSemester, setSelectedSemester] = useState('3rd');
  const [feedback, setFeedback] = useState({ subject: '', comments: '' });

  const handleFeedbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Feedback submitted successfully!');
    setFeedback({ subject: '', comments: '' });
  };

  const renderContent = () => {
    switch (activeSection) {
      case 'timetable':
        return (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-orange-100 rounded-lg">
                <Calendar className="h-6 w-6 text-orange-600" />
              </div>
              <div className="flex-grow">
                <h2 className="text-2xl font-bold text-gray-900">Class Timetable</h2>
              </div>
              <div className="flex gap-2">
                {Object.keys(semesterSchedules).map((semester) => (
                  <button
                    key={semester}
                    onClick={() => setSelectedSemester(semester)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      selectedSemester === semester
                        ? 'bg-orange-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {semester} Semester
                  </button>
                ))}
              </div>
            </div>
            <div className="mb-4">
              <h3 className="text-lg font-semibold text-gray-800 mb-2">
                {selectedSemester} Semester Schedule
              </h3>
            </div>
            <div className="space-y-4">
              {semesterSchedules[selectedSemester].map((slot, index) => (
                <div key={index} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <div className="flex-shrink-0 w-20 text-center">
                    <div className="text-sm font-medium text-orange-600">{slot.time.split(' - ')[0]}</div>
                    <div className="text-xs text-gray-500">{slot.time.split(' - ')[1]}</div>
                  </div>
                  <div className="flex-grow">
                    <h3 className="font-semibold text-gray-900">{slot.subject}</h3>
                    <p className="text-sm text-gray-600">{slot.room} • {slot.type}</p>
                  </div>
                  <div className="flex-shrink-0">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      slot.type === 'Lecture' 
                        ? 'bg-blue-100 text-blue-800' 
                        : slot.type === 'Practical' 
                        ? 'bg-green-100 text-green-800'
                        : 'bg-purple-100 text-purple-800'
                    }`}>
                      {slot.type}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case 'notices':
        return (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-orange-100 rounded-lg">
                <Bell className="h-6 w-6 text-orange-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900">Academic Notices</h2>
            </div>
            <div className="space-y-4">
              {notices.map((notice) => (
                <div key={notice.id} className="p-4 border border-gray-200 rounded-lg hover:border-orange-200 hover:shadow-sm transition-all">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-semibold text-gray-900 flex items-center gap-2">
                      {notice.title}
                      {notice.isNew && (
                        <span className="px-2 py-1 bg-red-100 text-red-800 text-xs rounded-full">New</span>
                      )}
                    </h3>
                    <span className="text-sm text-gray-500">{notice.date}</span>
                  </div>
                  <p className="text-gray-600 text-sm">{notice.description}</p>
                </div>
              ))}
            </div>
          </div>
        );

      case 'events':
        return (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-orange-100 rounded-lg">
                <Users className="h-6 w-6 text-orange-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900">Upcoming Events</h2>
            </div>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {events.map((event) => (
                <div key={event.id} className="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
                  <img 
                    src={event.image} 
                    alt={event.name}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-4">
                    <h3 className="font-semibold text-gray-900 mb-2">{event.name}</h3>
                    <p className="text-sm text-gray-600 mb-3">{event.date}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-500">{event.registered} registered</span>
                      <button className="bg-orange-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-orange-700 transition-colors">
                        Register
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case 'feedback':
        return (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-orange-100 rounded-lg">
                <MessageSquare className="h-6 w-6 text-orange-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900">User Feedback</h2>
            </div>
            <form onSubmit={handleFeedbackSubmit} className="space-y-6">
              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-2">
                  Subject
                </label>
                <input
                  type="text"
                  id="subject"
                  value={feedback.subject}
                  onChange={(e) => setFeedback({ ...feedback, subject: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all"
                  placeholder="Enter feedback subject"
                  required
                />
              </div>
              <div>
                <label htmlFor="comments" className="block text-sm font-medium text-gray-700 mb-2">
                  Comments
                </label>
                <textarea
                  id="comments"
                  rows={6}
                  value={feedback.comments}
                  onChange={(e) => setFeedback({ ...feedback, comments: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent transition-all resize-none"
                  placeholder="Share your thoughts and suggestions..."
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full bg-orange-600 text-white py-3 px-6 rounded-lg font-medium hover:bg-orange-700 transition-colors"
              >
                Submit Feedback
              </button>
            </form>
          </div>
        );

      case 'tests':
        return (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-orange-100 rounded-lg">
                <ClipboardList className="h-6 w-6 text-orange-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900">Test Schedules</h2>
            </div>
            <div className="space-y-4">
              {upcomingTests.map((test) => (
                <div key={test.id} className="p-4 border border-gray-200 rounded-lg hover:border-orange-200 hover:shadow-sm transition-all">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-gray-900">{test.subject}</h3>
                    <span className="px-3 py-1 bg-yellow-100 text-yellow-800 text-xs rounded-full">
                      Upcoming
                    </span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm text-gray-600">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      {test.date}
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      {test.time}
                    </div>
                    <div className="flex items-center gap-2">
                      <GraduationCap className="h-4 w-4" />
                      {test.assignedTo}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case 'ebooks':
        return (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-orange-100 rounded-lg">
                <BookOpen className="h-6 w-6 text-orange-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900">E-Books Library</h2>
            </div>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              {ebooks.map((book) => (
                <div key={book.id} className="group cursor-pointer">
                  <div className="relative overflow-hidden rounded-lg shadow-sm group-hover:shadow-lg transition-shadow">
                    <img 
                      src={book.cover} 
                      alt={book.title}
                      className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-300"></div>
                  </div>
                  <div className="mt-3">
                    <h3 className="font-semibold text-gray-900 text-sm leading-tight">{book.title}</h3>
                    <p className="text-sm text-gray-600 mt-1">{book.author}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case 'map':
        return (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-orange-100 rounded-lg">
                <MapPin className="h-6 w-6 text-orange-600" />
              </div>
              <h2 className="text-2xl font-bold text-gray-900">Campus Map</h2>
            </div>
            <div className="space-y-4">
              <div className="bg-gradient-to-r from-orange-50 to-blue-50 rounded-lg p-4 border border-orange-100">
                <div className="flex items-center gap-3 mb-2">
                  <MapPin className="h-5 w-5 text-orange-600" />
                  <h3 className="font-semibold text-gray-900">Sikkim Manipal Institute of Technology</h3>
                </div>
                <p className="text-sm text-gray-600 mb-3">Majitar, Rangpo, East Sikkim - 737136</p>
                <a
                  href="https://www.google.com/maps/place/Sikkim+Manipal+Institute+of+Technology/data=!4m7!3m6!1s0x39e6a744f1c716eb:0xd8c443744048d4d1!8m2!3d27.1825726!4d88.5018294!16s%2Fg%2F11bzzz9171!19sChIJ6xbH8USn5jkR0dRIQHRDxNg?authuser=0&hl=en&rclk=1"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 bg-orange-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-orange-700 transition-colors"
                >
                  <MapPin className="h-4 w-4" />
                  Open in Google Maps
                </a>
              </div>
              
              <div className="bg-gray-100 rounded-lg h-96 overflow-hidden">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3544.8234567890123!2d88.5018294!3d27.1825726!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39e6a744f1c716eb%3A0xd8c443744048d4d1!2sSikkim%20Manipal%20Institute%20of%20Technology!5e0!3m2!1sen!2sin!4v1234567890123!5m2!1sen!2sin"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="rounded-lg"
                ></iframe>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40">
        <div className="flex items-center justify-between px-6 py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="lg:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
            >
              {isSidebarOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
            <div className="flex items-center gap-3">
              <img 
                src="/smit logo.png" 
                alt="SMIT Logo" 
                className="w-10 h-10 object-contain"
              />
              <div>
                <h1 className="text-xl font-bold text-gray-900">Digital Student Assistance App</h1>
                <p className="text-sm text-gray-600">Sikkim Manipal Institute of Technology</p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:block text-right">
              <p className="text-sm font-medium text-gray-900">Welcome, Student</p>
              <p className="text-xs text-gray-600">January 15, 2025</p>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className={`${
          isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
        } lg:translate-x-0 fixed lg:static inset-y-0 left-0 z-30 w-64 bg-white border-r border-gray-200 transition-transform duration-300 ease-in-out`}>
          <div className="p-6 pt-20 lg:pt-6">
            <nav className="space-y-2">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveSection(item.id);
                      setIsSidebarOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-left transition-all ${
                      activeSection === item.id
                        ? 'bg-orange-100 text-orange-800 border border-orange-200'
                        : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                    <span className="font-medium">{item.label}</span>
                    {activeSection === item.id && (
                      <ChevronRight className="h-4 w-4 ml-auto" />
                    )}
                  </button>
                );
              })}
            </nav>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6 lg:ml-0">
          <div className="max-w-7xl mx-auto">
            {renderContent()}
          </div>
        </main>
      </div>

      {/* Mobile Overlay */}
      {isSidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-20 lg:hidden"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}
    </div>
  );
}

export default App;